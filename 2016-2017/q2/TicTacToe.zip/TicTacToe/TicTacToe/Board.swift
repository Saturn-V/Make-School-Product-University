//
//  Board.swift
//  TicTacToe
//
//  Created by Alex Aaron Peña on 12/12/16.
//  Copyright © 2016 Alex Aaron Peña. All rights reserved.
//

import Foundation

struct Board {
    var currentTurn: String?
    var game = [["", "", ""], ["", "", ""], ["", "", ""]]
    
    init() {
        self.currentTurn = "X"
    }
    
    mutating func move(x: Int, y: Int) {
        if game[y][x].isEmpty {
            game[y][x] = currentTurn!
            
            if currentTurn! == "X" {
                currentTurn = "O"
            } else {
                currentTurn = "X"
            }
        }
    }
    
    func winner() -> Bool {
        //        for slice in 0 ..< 5 {
        //            print("Slice \(slice)");
        //            let z = slice < 3 ? 0 : slice - 3 + 1;
        //            for j in z ..< (slice - z) {
        //                print("\(game[j][slice - j])");
        //            }
        //            print("\n");
        //        }
        //
        //        for y in 0...2 {
        //            for x in 0...2 {
        //                if !game[y][x].isEmpty {
        //
        //                }
        //            }
        //        }
        var winner: String?
        var game_over = false
        
        if game[0][0] == game[0][1] && game[0][0] == game[0][2] && !game[0][0].isEmpty {
            
            winner = "\(game[0][0]) has won the game!"
            game_over = true
            
        } else if game[1][0] == game[1][1] && game[1][0] == game[1][2] && !game[1][0].isEmpty{
            
            winner = "\(game[1][0]) has won the game!"
            game_over = true
            
        } else if game[2][0] == game[2][1] && game[2][0] == game[2][2] && !game[2][0].isEmpty {
            
            winner = "\(game[2][0]) has won the game!"
            game_over = true
            
        } else if game[0][0] == game[1][0] && game[0][0] == game[2][0] && !game[0][0].isEmpty {
            
            winner = "\(game[0][0]) has won the game!"
            game_over = true
            
        } else if game[0][1] == game[1][1] && game[0][1] == game[2][1] && !game[0][1].isEmpty {
            
            winner = "\(game[0][1]) has won the game!"
            game_over = true
            
        } else if game[0][2] == game[1][2] && game[0][2] == game[2][2] && !game[0][2].isEmpty {
            
            winner = "\(game[0][2]) has won the game!"
            game_over = true
            
        } else if game[0][0] == game[1][1] && game[0][0] == game[2][2] && !game[0][0].isEmpty {
            
            winner = "\(game[0][0]) has won the game!"
            game_over = true
            
        } else if game[0][2] == game[1][1] && game[0][2] == game[2][0] && !game[0][2].isEmpty {
            
            winner = "\(game[0][2]) has won the game!"
            game_over = true
            
        } else {
            winner = "No Winner"
        }
        
        print(winner!)
        return game_over
    }
}
