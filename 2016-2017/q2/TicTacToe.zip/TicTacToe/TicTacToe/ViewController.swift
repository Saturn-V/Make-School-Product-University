//
//  ViewController.swift
//  TicTacToe
//
//  Created by Alex Aaron Peña on 12/12/16.
//  Copyright © 2016 Alex Aaron Peña. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        var boardView = BoardView(boardWidth: 250, boardHeight: 250)
        boardView.center = self.view.center
        self.view.addSubview(boardView)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

