//
//  BoardView.swift
//  TicTacToe
//
//  Created by Alex Aaron Peña on 12/12/16.
//  Copyright © 2016 Alex Aaron Peña. All rights reserved.
//

import Foundation
import UIKit

class BoardView: UIView {
    
    var BoardViewFrame: CGRect?
    var fieldWidth: CGFloat?
    var fieldHeight: CGFloat?
    var boardWidth: CGFloat?
    var boardHeight: CGFloat?
    var fields: [[UILabel]] = [[UILabel(), UILabel(), UILabel()],
                               [UILabel(), UILabel(), UILabel()],
                               [UILabel(), UILabel(), UILabel()]
        
        
    ]
    var currentGame = Board()
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    init(fieldWidth: CGFloat, fieldHeight: CGFloat) {
        
        self.fieldWidth = fieldWidth
        self.fieldHeight = fieldHeight
        
        self.boardWidth = fieldWidth * 3
        self.boardHeight = fieldHeight * 3
        
        self.BoardViewFrame = CGRect(x: 0, y: 0, width: self.boardWidth!, height: self.boardHeight!)
        
        super.init(frame: BoardViewFrame!)
        
        generateFields(fieldWidth: self.fieldWidth!, fieldHeight: self.fieldHeight!)
    }
    
    init(boardWidth: CGFloat, boardHeight: CGFloat) {
        
        self.fieldWidth = boardWidth / 3
        self.fieldHeight = boardHeight / 3
        
        self.boardWidth = boardWidth
        self.boardHeight = boardHeight
        
        self.BoardViewFrame = CGRect(x: 0, y: 0, width: boardWidth, height: boardHeight)
        
        super.init(frame: BoardViewFrame!)
        
        generateFields(fieldWidth: self.fieldWidth!, fieldHeight: self.fieldHeight!)
    }
    
    func generateFields(fieldWidth: CGFloat, fieldHeight: CGFloat) {
        for posY in 0...2 {
            for posX in 0...2 {
                let fieldFrame = CGRect(x: fieldWidth * CGFloat(posX), y: fieldHeight * CGFloat(posY), width: fieldWidth, height: fieldHeight)
                let fieldView = UILabel(frame: fieldFrame)
                fieldView.layer.borderColor = (UIColor.black).cgColor
                fieldView.layer.borderWidth = 1
                fieldView.isUserInteractionEnabled = true
                fieldView.textAlignment = .center
                
                let tappedGesture = UITapGestureRecognizer(target: self, action: #selector(createMove))
                
                fieldView.addGestureRecognizer(tappedGesture)
                
                fields[posY][posX] = fieldView
                self.addSubview(fieldView)
            }
        }
    }
    
    func createMove(sender: UITapGestureRecognizer) {
        let field = sender.location(in: self)
        if !currentGame.winner() {
            if field.x <= fieldWidth!  {
                if field.y <= fieldHeight! {
                    print("Player \(currentGame.currentTurn!) moved: 0,0")
                    fields[0][0].text = "\(currentGame.currentTurn!)"
                    currentGame.move(x: 0, y: 0)
                    print("Player \(currentGame.currentTurn!) is next")
                    
                } else if field.y <= fieldHeight! * 2 {
                    print("Player \(currentGame.currentTurn!) moved: 0,1")
                    fields[1][0].text = "\(currentGame.currentTurn!)"
                    currentGame.move(x: 0, y: 1)
                    print("Player \(currentGame.currentTurn!) is next")
                } else {
                    print("Player \(currentGame.currentTurn!) moved: 0,2")
                    fields[2][0].text = "\(currentGame.currentTurn!)"
                    currentGame.move(x: 0, y: 2)
                    print("Player \(currentGame.currentTurn!) is next")
                }
            } else  if field.x <= fieldWidth! * 2 {
                if field.y <= fieldHeight! {
                    print("Player \(currentGame.currentTurn!) moved: 1,0")
                    fields[0][1].text = "\(currentGame.currentTurn!)"
                    currentGame.move(x: 1, y: 0)
                    print("Player \(currentGame.currentTurn!) is next")
                } else if field.y <= fieldHeight! * 2 {
                    print("Player \(currentGame.currentTurn!) moved: 1,1")
                    fields[1][1].text = "\(currentGame.currentTurn!)"
                    currentGame.move(x: 1, y: 1)
                    print("Player \(currentGame.currentTurn!) is next")
                } else {
                    print("Player \(currentGame.currentTurn!) moved: 1,2")
                    fields[2][1].text = "\(currentGame.currentTurn!)"
                    currentGame.move(x: 1, y: 2)
                    print("Player \(currentGame.currentTurn!) is next")
                }
            } else  if field.x <= boardWidth!  {
                if field.y <= fieldHeight! {
                    print("Player \(currentGame.currentTurn!) moved: 2,0")
                    fields[0][2].text = "\(currentGame.currentTurn!)"
                    currentGame.move(x: 2, y: 0)
                    print("Player \(currentGame.currentTurn!) is next")
                } else if field.y <= fieldHeight! * 2 {
                    print("Player \(currentGame.currentTurn!) moved: 2,1")
                    fields[1][2].text = "\(currentGame.currentTurn!)"
                    currentGame.move(x: 2, y: 1)
                    print("Player \(currentGame.currentTurn!) is next")
                } else {
                    print("Player \(currentGame.currentTurn!) moved: 2,2")
                    fields[2][2].text = "\(currentGame.currentTurn!)"
                    currentGame.move(x: 2, y: 2)
                    print("Player \(currentGame.currentTurn!) is next")
                }
            }
        }
    }
}
